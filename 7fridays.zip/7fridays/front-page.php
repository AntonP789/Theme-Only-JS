<?php get_header(); ?>
<div class="content">
    <?php include(get_theme_root().'/'.get_option('stylesheet').'/template-parts/main-flexible-content.php');?> 
</div><!--End Content-->
<?php get_footer(); ?>
