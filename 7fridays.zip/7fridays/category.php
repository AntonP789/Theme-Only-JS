<?php get_header(); ?>

<?php include( 'template-parts/blog-part.php' ); ?>

<?php get_footer(); ?>