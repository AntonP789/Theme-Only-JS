<div class="default-modal custom-modal" id="default-modal">
    <div class="modal-content">
        <span class="close-button">×</span>
        <h1>Hello, I am a modal!</h1>
    </div>
</div>

<!-- this code opened modal -->
<button class="open-modal" attr-modal-name="default-modal">Click the modal! default</button>